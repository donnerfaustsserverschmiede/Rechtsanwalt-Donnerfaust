# Rechtsanwalt-Donnerfaust

Digitale Kanzleiverwaltung.

## Version 0.1
Enthalten:
- öffentliche Startseite
- Mitarbeiterbereich
- Dashboard
- Akten & Fälle
- Mandanten
- Termine / Kalender
- Aufgaben
- Dokumente
- Gebühren / Rechnungen
- Nachrichten
- Benachrichtigungen
- Ankündigungen
- Notizen
- zentrale Suche
- Mitarbeiter
- Verwaltung
- responsive Smartphone-Oberfläche
- PWA-Grundlage
- lokale Demo-Daten

## GitHub Pages
Die Dateien können direkt in das Repository `Rechtsanwalt-Donnerfaust` gelegt werden. Danach GitHub Pages auf dem Branch `main` aktivieren.

## Hinweis
Dies ist zunächst ein Frontend-Prototyp. Für echte Mandantendaten müssen Authentifizierung, Datenbank, Rechteverwaltung, Dokumentenspeicher, Backups, Verschlüsselung und Datenschutz professionell umgesetzt werden.
